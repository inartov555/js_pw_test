export type SearchNameFromToType = {
  name: string;
  from: string;
  to: string;
};
